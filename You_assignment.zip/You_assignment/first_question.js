for(let i=0; i<20; i++){
    console.log(i)
    setTimeout(function(){
      console.log('The number is: ' + i);
    }, 1000)
  }